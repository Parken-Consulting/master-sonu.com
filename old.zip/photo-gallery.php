
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<?php include_once 'dbwork/dbconfig.php';?>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<!--<link href="css/style2.css" media="screen" type="text/css" rel="stylesheet">
<link href="css/style3.css" media="print" type="text/css" rel="stylesheet">-->
<link rel="stylesheet" href="css/jquery.fancybox-1.3.4.css" type="text/css" media="screen" />
<link rel="stylesheet" href="css/nivo-slider.css" type="text/css" media="screen" />

	<script type="text/javascript" src="js/jquery-1.6.4.min.js"></script>
	<script type="text/javascript" src="js/jquery.vticker.1.4.js"></script>
	<script type="text/javascript" src="js/niecScript.js"></script>
	<script type="text/javascript" src="js/jquery.hoverIntent.minified.js"></script>
	<script type="text/javascript" src="js/highlight.js"></script>
	<script type="text/javascript" src="js/jquery.tooltip.min.js"></script>
	<script type="text/javascript" src="js/jquery.fancybox-1.3.4.pack.js"></script>
	<script type="text/javascript" src="js/jquery.easing-1.3.pack.js"></script>
	<script type="text/javascript" src="js/jquery.scrolltopcontrol.js"></script>


<title>Martial arts, Martial arts training, Martial arts classes, Martial arts academy, Martial arts schools, Martial arts clubs, Martial arts schools, Martial arts gyms, Martial arts training center, Martial arts coaching, Martial arts for kids, Martial arts lessons, Kids martial arts, Martial arts weapons, Martial arts styles</title>



<meta name="keywords" content="Martial arts, Martial arts training, Martial arts classes, Martial arts academy, Martial arts schools, Martial arts clubs, Martial arts schools, Martial arts gyms, Martial arts training center, Martial arts coaching, Martial arts for kids, Martial arts lessons, Kids martial arts, Martial arts weapons, Martial arts styles"> 



<meta name="description" content="World class training with our international expert Master Sonu,Learn Martial art Gopalganj, Karate Classes in Gopalganj, Mixed Martial Arts in Gopalganj, Muay thai Kick Boxing in Gopalganj, Karate in Gopalganj, Mixed martial arts in Gopalganj, Karate and martial art training school in Gopalganj, Martial arts in India, Brazilian Jiu Jutsu classes in Gopalganj, Self Defense and fitness classes in Gopalganj,."/>  



<meta name="msvalidate.01" content="681AFDCD6521C46D6AB3B7907F7680D9" />

<meta name="google-site-verification" content="O9OrORBjZrcGMlTDZ5UdOg7AhIuOZvWoHOaTlRmwQ1o" />

<script type="text/javascript">

  var _gaq = _gaq || [];

  _gaq.push(['_setAccount', 'UA-34258293-1']);

  _gaq.push(['_trackPageview']);

  (function() {

    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;

    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';

    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);

  })();

</script>

<meta name="zipcode" content="110048" />

<meta name="city" content="Gopalganj," />

<meta name="state" content="Gopalganj," />

<meta name="country" content="India" />

<meta name="geo.country" content="India" />

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

<meta name="author" content="Ajay Kumar" /> 

<meta name="language" content="EN" /> 

<meta name="robots" content="index, follow" /> 

<meta name="googlebot" content="index, follow" /> 

<meta name="revisit-after" content="2 days" /> 

<meta name="reply-to" content="seoajay94@gmail.com" /> 

<meta name="document-classification" content="Internet" /> 

<meta name="document-type" content="Public" /> 

<meta name="document-rating" content="Safe for Kids" /> 

<meta name="document-distribution" content="Global" /> 

<meta name="owner" content="mastersonu.com" /> 

<meta name="copyright" content="(c) 2013" />





<link href="css/style.css" rel="stylesheet" type="text/css" />

<link href="css/menu.css" rel="stylesheet" type="text/css" />

<link href="css/js-image-slider.css" rel="stylesheet" type="text/css" />

<script src="js/js-image-slider.js" type="text/javascript"></script>

</head>



<body topmargin="0" bottommargin="0">

<table width="950" border="0" align="center" cellpadding="0" cellspacing="0">

  <tr>

    <td height="105" colspan="3" valign="top" background="image/header.jpg"><table width="950" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td width="206" rowspan="4" align="center" valign="middle"><img src="image/logo6.png" width="206" height="121" /></td>

        <td width="514">&nbsp;</td>

        <td width="230" rowspan="3"><table width="100%" border="0" cellspacing="0" cellpadding="0">

          <tr>

            <td colspan="6" >&nbsp;</td>

          </tr>

          <tr>

            <td width="33%" class="call">Call Us &nbsp;&nbsp;&nbsp;&nbsp;: </td>

            <td colspan="5" align="left" class="no">+91 9507-735-233 </td>

          </tr>

          <tr>

            <td colspan="6" height="3px"></td>

          </tr>

          <tr>

            <td class="call">Email  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: </td>

            <td colspan="5" align="left" class="no">info@mastersonu.com</td>

          </tr>

          <tr>

            <td colspan="6" height="3px"></td>

          </tr>

          <tr>

            <td class="call">Follow us :</td>

            <td width="12%"><img src="image/icon-linkedin.png" width="23" height="24" border="0" usemap="#Map3" /> </td>

            <td width="12%"><img src="image/icon-facebook.png" width="23" height="24" border="0" usemap="#Map" /></td>

            <td width="13%"><img src="image/icon-twitter.png" width="23" height="24" border="0" usemap="#Map2" /></td>

            <td width="12%"><img src="image/blog.png" width="23" height="24" border="0" usemap="#Map4" /></td>

            <td width="18%"><img src="image/youtube-icon.png" width="23" height="24" border="0" usemap="#Map8" /></td>

          </tr>

          <tr>

            <td class="call">&nbsp;</td>

            <td>&nbsp;</td>

            <td>&nbsp;</td>

            <td>&nbsp;</td>

            <td>&nbsp;</td>

            <td>&nbsp;</td>

          </tr>

        </table>

          <map name="Map" id="Map53">

            <area shape="rect" coords="2,2,21,22" href="http://www.facebook.com/KarateMixedMartialArtsKickBoxingSchool" target="_blank" />

          </map>

          <map name="Map2" id="Map223">

            <area shape="rect" coords="2,2,22,22" href="https://twitter.com/martialartjk" target="_blank" />

          </map>

          <map name="Map3" id="Map323">

            <area shape="rect" coords="1,2,20,20" href="http://in.linkedin.com/pub/mixed-martial-arts-mma-training-classes-in-india/30/171/300" target="_blank" />

          </map>

          <map name="Map4" id="Map423">

            <area shape="rect" coords="3,2,22,22" href="http://mixedmartial-art.blogspot.in/" target="_blank" />

          </map>

          <map name="Map" id="Map53">

            <area shape="rect" coords="2,2,21,22" href="http://www.facebook.com/KarateMixedMartialArtsKickBoxingSchool" target="_blank" />

          </map>

          <map name="Map2" id="Map223">

            <area shape="rect" coords="2,2,22,22" href="https://twitter.com/martialartjk" target="_blank" />

          </map>

          <map name="Map3" id="Map323">

            <area shape="rect" coords="1,2,20,20" href="http://in.linkedin.com/pub/mixed-martial-arts-mma-training-classes-in-india/30/171/300" target="_blank" />

          </map>

          <map name="Map4" id="Map423">

            <area shape="rect" coords="3,2,22,22" href="http://mixedmartial-art.blogspot.in/" target="_blank" />

          </map>

          <map name="Map" id="Map7">

            <area shape="rect" coords="2,2,21,22" href="http://www.facebook.com/KarateMixedMartialArtsKickBoxingSchool" target="_blank" />

          </map>

          <map name="Map2" id="Map24">

            <area shape="rect" coords="2,2,22,22" href="https://twitter.com/martialartjk" target="_blank" />

          </map>

          <map name="Map3" id="Map34">

            <area shape="rect" coords="1,2,20,20" href="http://in.linkedin.com/pub/mixed-martial-arts-mma-training-classes-in-india/30/171/300" target="_blank" />

          </map>

          <map name="Map4" id="Map44">

            <area shape="rect" coords="3,2,22,22" href="http://mixedmartial-art.blogspot.in/" target="_blank" />

          </map>

          <map name="Map" id="Map52">

            <area shape="rect" coords="2,2,21,22" href="http://www.facebook.com/KarateMixedMartialArtsKickBoxingSchool" target="_blank" />

          </map>

          <map name="Map2" id="Map222">

            <area shape="rect" coords="2,2,22,22" href="https://twitter.com/martialartjk" target="_blank" />

          </map>

          <map name="Map3" id="Map322">

            <area shape="rect" coords="1,2,20,20" href="http://in.linkedin.com/pub/mixed-martial-arts-mma-training-classes-in-india/30/171/300" target="_blank" />

          </map>

          <map name="Map4" id="Map422">

            <area shape="rect" coords="3,2,22,22" href="http://mixedmartial-art.blogspot.in/" target="_blank" />

          </map>

          <map name="Map" id="Map6">

            <area shape="rect" coords="2,2,21,22" href="http://www.facebook.com/KarateMixedMartialArtsKickBoxingSchool" target="_blank" />

          </map>

          <map name="Map2" id="Map23">

            <area shape="rect" coords="2,2,22,22" href="https://twitter.com/martialartjk" target="_blank" />

          </map>

          <map name="Map3" id="Map33">

            <area shape="rect" coords="1,2,20,20" href="http://in.linkedin.com/pub/mixed-martial-arts-mma-training-classes-in-india/30/171/300" target="_blank" />

          </map>

          <map name="Map4" id="Map43">

            <area shape="rect" coords="3,2,22,22" href="http://mixedmartial-art.blogspot.in/" target="_blank" />

          </map>

          <map name="Map" id="Map52">

            <area shape="rect" coords="2,2,21,22" href="http://www.facebook.com/KarateMixedMartialArtsKickBoxingSchool" target="_blank" />

          </map>

          <map name="Map2" id="Map222">

            <area shape="rect" coords="2,2,22,22" href="https://twitter.com/martialartjk" target="_blank" />

          </map>

          <map name="Map3" id="Map322">

            <area shape="rect" coords="1,2,20,20" href="http://in.linkedin.com/pub/mixed-martial-arts-mma-training-classes-in-india/30/171/300" target="_blank" />

          </map>

          <map name="Map4" id="Map422">

            <area shape="rect" coords="3,2,22,22" href="http://mixedmartial-art.blogspot.in/" target="_blank" />

          </map>

          <map name="Map" id="Map6">

            <area shape="rect" coords="2,2,21,22" href="http://www.facebook.com/KarateMixedMartialArtsKickBoxingSchool" target="_blank" />

          </map>

          <map name="Map2" id="Map23">

            <area shape="rect" coords="2,2,22,22" href="https://twitter.com/martialartjk" target="_blank" />

          </map>

          <map name="Map3" id="Map33">

            <area shape="rect" coords="1,2,20,20" href="http://in.linkedin.com/pub/mixed-martial-arts-mma-training-classes-in-india/30/171/300" target="_blank" />

          </map>

          <map name="Map4" id="Map43">

            <area shape="rect" coords="3,2,22,22" href="http://mixedmartial-art.blogspot.in/" target="_blank" />

          </map>

          <map name="Map8" id="Map8">

            <area shape="rect" coords="3,4,21,20" href="https://www.youtube.com/channel/UCW8btSfQ2v0qEljqkxvjgsg" target="_blank" />

          </map>

          <map name="Map" id="Map5">

            <area shape="rect" coords="2,2,21,22" href="http://www.facebook.com/KarateMixedMartialArtsKickBoxingSchool" target="_blank" />

          </map>

          <map name="Map2" id="Map22">

            <area shape="rect" coords="2,2,22,22" href="https://twitter.com/martialartjk" target="_blank" />

          </map>

          <map name="Map3" id="Map32">

            <area shape="rect" coords="1,2,20,20" href="http://in.linkedin.com/pub/mixed-martial-arts-mma-training-classes-in-india/30/171/300" target="_blank" />

          </map>

          <map name="Map4" id="Map42">

            <area shape="rect" coords="3,2,22,22" href="http://mixedmartial-art.blogspot.in/" target="_blank" />

          </map>

          <map name="Map" id="Map5">

            <area shape="rect" coords="2,2,21,22" href="http://www.facebook.com/KarateMixedMartialArtsKickBoxingSchool" target="_blank" />

          </map>

          <map name="Map2" id="Map22">

            <area shape="rect" coords="2,2,22,22" href="https://twitter.com/martialartjk" target="_blank" />

          </map>

          <map name="Map3" id="Map32">

            <area shape="rect" coords="1,2,20,20" href="http://in.linkedin.com/pub/mixed-martial-arts-mma-training-classes-in-india/30/171/300" target="_blank" />

          </map>

          <map name="Map4" id="Map42">

            <area shape="rect" coords="3,2,22,22" href="http://mixedmartial-art.blogspot.in/" target="_blank" />

          </map>

          <map name="Map" id="Map">

            <area shape="rect" coords="2,2,21,22" href="http://www.facebook.com/KarateMixedMartialArtsKickBoxingSchool" target="_blank" />

          </map>

          <map name="Map2" id="Map2">

            <area shape="rect" coords="2,2,22,22" href="https://twitter.com/martialartjk" target="_blank" />

          </map>

          <map name="Map3" id="Map3">

            <area shape="rect" coords="1,2,20,20" href="http://in.linkedin.com/pub/mixed-martial-arts-mma-training-classes-in-india/30/171/300" target="_blank" />

          </map>

          <map name="Map4" id="Map4">

            <area shape="rect" coords="3,2,22,22" href="http://mixedmartial-art.blogspot.in/" target="_blank" />

          </map>

          </td>

      </tr>

      <tr>

        <td ><img src="image/Sansinkan-logo.png"></td>

        </tr>

      <tr>

        <td rowspan="2">&nbsp;</td>

        </tr>

      

      <tr>

        <td valign="top">&nbsp;</td>

      </tr>

      

    </table></td>

  </tr>

  <tr>

  

  

    <td height="40" colspan="3" background="image/menu.jpg">

    <ul id="menu">

		<li><a href="index.html">Home</a></li>



		<li>

			<a href="">Our Profile</a>

			<ul>

				<li><a href="Official.html">Official</a></li>

				<li><a href="msonu.html">Master Sonu</a></li>

				<li><a href="news.php">News & Events </a></li>

	      </ul>

		</li>

				<li><a href="photo-gallery.php">Photo Gallery</a></li>

				<li><a href="Centers.html">Centers</a></li>

				<li><a href="">Classes</a>

				<ul>
					<li><a href="wushu.html">Wushu</a></li>

					<li><a href="karate.html">Karate</a></li>

					<li><a href="boxing.html">Boxing</a></li>

					<li><a href="kudo.html">Kudo</a></li>

					<li><a href="modelgym.html">Model Gym</a></li>

					<li><a href="judo.html">Judo</a></li>

                    <li><a href="kick-boxing.html">Kick Boxing</a></li>

					<li><a href="kubodo.html">Kubodo</a></li>

					<li><a href="mixed-martial-arts.html">MMA</a></li>

                    <li><a href="nanchaku.html">Nan Chaku</a></li>

					<li><a href="spear.html">Spear</a></li>
					<li><a href="Stick.html">Stick</a></li>
                    <li><a href="Sword.html">Sword</a></li>
                    <li><a href="selfdefence.html">Self Defence</a></li>
                    <li><a href="kama.html">Kama, Tonfa, Sai</a></li>
                    <li><a href="stunt.html">Stunt</a></li>
                    <li><a href="gymnastics.html">Gymnastic</a></li>
                    <li><a href="fighting.html">Fighting Acting</a></li>
                    <li><a href="womenselfdefence.html">Women's Self Defence</a></li>
                    <li><a href="yoga.html">Yoga</a></li>
                    <li><a href="weightloss.html">Weight Loss</a></li>
                    <li><a href="discipline.html">Discipline</a></li>
                    <li><a href="bodyfitness.html">Body Fitness</a></li>

				  </ul>

				</li>

				<li><a href="">Programes</a>

					<ul>

					<li><a href="junior-program-age.html">Age 3-13 Years</a></li>

					<li><a href="junior-program-age-old.html">Age 14-18 Years</a></li>

					<li><a href="adult-program-age-old.html">Age 18-30 Years</a></li>

					<li><a href="smart-adult-program-age-old.html">Age 30 Years Above </a></li>

					<li><a href="woman-special-program-age-old.html">Woman Special</a></li>

					<li><a href="black-belt.html">Black Belt Traing</a></li>

					<li><a href="self-defence.html">Self Defence & Fitness</a></li>

					<li><a href="workshops-corporate-events.html">Workshop</a></li>

					</ul>
<li><a href="student.php">Student Corner</a></li><li><a href="admin/index.html">Admin Zone</a></li>
		</li>

					<li><a href="conntact-us.html">Contact Us</a></li>

		</ul>

		</li>

	</ul>    </td>

  </tr>

  <tr>

    <td colspan="3" align="center"><img src="image/msonu.jpg" width="950" height="250" /></td>

  </tr>

  <tr>

    <td colspan="3" bgcolor="b19860">&nbsp;</td>

  </tr>

  <tr>

    <td colspan="3" align="center" valign="top" bgcolor="#D4D3BE"><table width="965" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td width="954" height="387" align="center" valign="top" bgcolor="#FFFFFF"><table width="913" border="0" cellspacing="0" cellpadding="0">

          <tr>

            <td height="3"></td>

          </tr>

          <tr>

            <td height="19" align="justify" valign="top">&nbsp;</td>

          </tr>

          <tr>

            <td><img src="image/photo-gallery.png" width="260" height="31" /></td>

          </tr>

  <tr><td>&nbsp;</td></tr>        

          <tr>
            
            <td align="center" ><font face="Verdana" color="#000000" size="2"></font><div>
            
      <!--dyanemic gallary-->
<?php
	$sql="SELECT * FROM photo";
	$result_set=mysql_query($sql);
	while($row=mysql_fetch_array($result_set))
	{
		?>
        <a class="grouped_elements" rel="group1" href="dbwork/uploads/<?php echo $row['photo']?>" ><img src="dbwork/uploads/<?php echo $row['photo']?>" width="200" height="150"></a>
        <?php
	}
			?>
            <!--end gallary-->      
            
            <!--<a class="grouped_elements" rel="group1" href="big/1.jpg" ><img src="thumb/1.jpg" alt=""/></a>
<a class="grouped_elements" rel="group1" href="big/2.jpg"><img src="thumb/2.jpg" alt=""/></a>
<a class="grouped_elements" rel="group1" href="big/3.jpg"><img src="thumb/3.jpg" alt=""/></a>
<a class="grouped_elements" rel="group1" href="big/4.jpg"><img src="thumb/4.jpg" alt=""/></a>
<a class="grouped_elements" rel="group1" href="big/5.jpg"><img src="thumb/5.jpg" alt=""/></a>
<a class="grouped_elements" rel="group1" href="big/6.jpg"><img src="thumb/6.jpg" alt=""/></a>
<a class="grouped_elements" rel="group1" href="big/7.jpg"><img src="thumb/7.jpg" alt=""/></a>
<a class="grouped_elements" rel="group1" href="big/8.jpg"><img src="thumb/8.jpg" alt=""/></a>
<a class="grouped_elements" rel="group1" href="big/9.jpg"><img src="thumb/9.jpg" alt=""/></a>
<a class="grouped_elements" rel="group1" href="big/10.jpg"><img src="thumb/10.jpg" alt=""/></a>
<a class="grouped_elements" rel="group1" href="big/11.jpg"><img src="thumb/11.jpg" alt=""/></a>
<a class="grouped_elements" rel="group1" href="big/12.jpg"><img src="thumb/12.jpg" alt=""/></a>
<a class="grouped_elements" rel="group1" href="big/13.jpg"><img src="thumb/13.jpg" alt=""/></a>
<a class="grouped_elements" rel="group1" href="big/14.jpg"><img src="thumb/14.jpg" alt=""/></a>
<a class="grouped_elements" rel="group1" href="big/15.jpg"><img src="thumb/15.jpg" alt=""/></a>
<a class="grouped_elements" rel="group1" href="big/16.jpg"><img src="thumb/16.jpg" alt=""/></a>
<a class="grouped_elements" rel="group1" href="big/17.jpg"><img src="thumb/17.jpg" alt=""/></a>
<a class="grouped_elements" rel="group1" href="big/18.jpg"><img src="thumb/18.jpg" alt=""/></a>
<a class="grouped_elements" rel="group1" href="big/19.jpg"><img src="thumb/19.jpg" alt=""/></a>
<a class="grouped_elements" rel="group1" href="big/20.jpg"><img src="thumb/20.jpg" alt=""/></a>
<a class="grouped_elements" rel="group1" href="big/21.jpg"><img src="thumb/21.jpg" alt=""/></a>
<a class="grouped_elements" rel="group1" href="big/22.jpg"><img src="thumb/22.jpg" alt=""/></a>
<a class="grouped_elements" rel="group1" href="big/23.jpg"><img src="thumb/23.jpg" alt=""/></a>
<a class="grouped_elements" rel="group1" href="big/24.jpg"><img src="thumb/24.jpg" alt=""/></a>
<!--<a class="grouped_elements" rel="group1" href="big/25.jpg"><img src="thumb/25.jpg" alt=""/></a>
<a class="grouped_elements" rel="group1" href="big/26.jpg"><img src="thumb/26.jpg" alt=""/></a>
<a class="grouped_elements" rel="group1" href="big/27.jpg"><img src="thumb/27.jpg" alt=""/></a>
<a class="grouped_elements" rel="group1" href="big/28.jpg"><img src="thumb/28.jpg" alt=""/></a>
<a class="grouped_elements" rel="group1" href="big/29.jpg"><img src="thumb/29.jpg" alt=""/></a>
<a class="grouped_elements" rel="group1" href="big/30.jpg"><img src="thumb/30.jpg" alt=""/></a>
<a class="grouped_elements" rel="group1" href="big/31.jpg"><img src="thumb/31.jpg" alt=""/></a>
<a class="grouped_elements" rel="group1" href="big/32.jpg"><img src="thumb/32.jpg" alt=""/></a>
<a class="grouped_elements" rel="group1" href="big/33.jpg"><img src="thumb/33.jpg" alt=""/></a>
<a class="grouped_elements" rel="group1" href="big/34.jpg"><img src="thumb/34.jpg" alt=""/></a>
<a class="grouped_elements" rel="group1" href="big/35.jpg"><img src="thumb/35.jpg" alt=""/></a>
<a class="grouped_elements" rel="group1" href="big/36.jpg"><img src="thumb/36.jpg" alt=""/></a>--></div>
<link rel="stylesheet" href="/css/jquery.fancybox-1.3.4.css" type="text/css" media="screen" />
<script type="text/javascript" src="js/jquery.fancybox-1.3.4.pack.js"></script>
<script type="text/javascript" src="js/jquery.easing-1.3.pack.js"></script>
<script type="text/javascript">
		$(document).ready(function() {
			$("a.grouped_elements").fancybox({
				'titlePosition'		: 'inside',
				'overlayShow'	: true,
				'transitionIn'	: 'elastic',
				'transitionOut'	: 'elastic'
			});
		});
</script></td>
            
          </tr>

          
          </table></td>

        </tr>

    </table></td>

  </tr>

  

  <tr>

    <td width="6" height="8px" bgcolor="#D4D3BE"></td>

    <td width="984" bgcolor="#D4D3BE"></td>

    <td width="4" bgcolor="#D4D3BE"></td>

  </tr>

  <tr>

    <td colspan="3" align="center" bgcolor="b19860"><table width="950" border="0" cellspacing="0" cellpadding="0">

      



      <tr>

        <td width="4" colspan="2">&nbsp;</td>

      </tr>

    </table></td>

  </tr>

  

  <tr>

    <td colspan="3" align="center" bgcolor="b19860"><table width="950" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td width="112" align="center" bgcolor="#26210E"><a href="index.html" class="link-footer">Home</a></td>

        <td width="9" bgcolor="#26210E"><font face="Arial" color="#cfc69e">|</font></td>

        <td width="112" align="center" bgcolor="#26210E"><a href="photo-gallery.php" class="link-footer">Photo Gallery</a></td>

        <td width="9" bgcolor="#26210E"><font face="Arial" color="#cfc69e">|</font></td>

        <td width="112" align="center" bgcolor="#26210E"><a href="conntact-us.html" class="link-footer">Contact us</a></td>

        <td width="10" bgcolor="#26210E">&nbsp;</td>

        <td width="114" align="center" bgcolor="#26210E">&nbsp;</td>

        <td width="10" bgcolor="#26210E">&nbsp;</td>

        <td width="114" align="center" bgcolor="#26210E">&nbsp;</td>

        <td width="348" bgcolor="#26210E">&nbsp;</td>

      </tr>

    </table></td>

  </tr>

  <tr>

    <td colspan="3" align="center" bgcolor="b19860"><table width="950" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td width="190" bgcolor="#26210E">&nbsp;</td>

        <td width="190" bgcolor="#26210E">&nbsp;</td>

        <td width="190" bgcolor="#26210E">&nbsp;</td>

        <td width="163" bgcolor="#26210E">&nbsp;</td>

        <td width="217" bgcolor="#26210E">&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>





</body>

</html>

