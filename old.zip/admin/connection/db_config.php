<?php
ob_start();
session_start();
$dbHost = "localhost";
$dbUser = "osinfoit";
$dbPass = "San@02028619";
$dbName = "usrsan";

?>